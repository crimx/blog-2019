package calc.front;

public enum TokenType {
	
	//数字
	NUMBER,
	
	//操作符
	PLUS, MINUS, STAR, SLASH,
    LEFT_PAREN, RIGHT_PAREN,
    
    //负数
    NEGATE,
	
	//结束
	EOF;
	
}

