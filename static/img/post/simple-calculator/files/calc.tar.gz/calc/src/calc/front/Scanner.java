package calc.front;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import static calc.front.TokenType.*;

/**
 * <h1>扫描器</h1>
 * 
 * <p>用于扫描输入文本，extractToken()每次返回一个Token.</p>
 * 
 * @author Crimx
 *
 */
public class Scanner {

	private int currentPos; // 当前字符位置
	private String line;    // 当前行

	public Scanner(Reader reader) throws IOException {
		
		line = (new BufferedReader(reader)).readLine();
		currentPos = 0; // 初始设置为0
	}
	
	/**
	 * 提取一个符号
	 * @throws Exception 
	 * **/
	public Token extractToken() throws Exception {
		
		// 空白符号
		while(Character.isWhitespace(currentChar())) {
			nextChar();
		}
		
		char currentChar = currentChar();
		
		// 数字处理
		if(Character.isDigit(currentChar) || currentChar == '.') {
			return extractNumber();
		}
		else {
			nextChar(); // 先消耗掉这个字符
			switch(currentChar) {
			case '+': return new Token(PLUS, '+'); 
			case '-': return new Token(MINUS, '-'); 
			case '*': return new Token(STAR, '*');
			case '/': return new Token(SLASH, '/'); 
			case '(': return new Token(LEFT_PAREN, '('); 
			case ')': return new Token(RIGHT_PAREN, ')');  
			case (char)0:return new Token(EOF); 
			default : throw new Exception("有未识别的字符 \""+ currentChar + "\" !");
			}
		}
	}
	
	/**
	 * 提取一个自然数
	 * @throws Exception 
	 * **/
	private Token extractNumber() throws Exception {
		
		StringBuffer res = new StringBuffer();
		boolean point = false; // 小数点
		char currentChar = currentChar();
		
		while(Character.isDigit(currentChar) || currentChar == '.') {
			
			if(currentChar() == '.') {
				if(point) {
					throw new Exception("数字不能有两个小数点！");
				}
				else {
					point = true;
				}
			}
			res.append(currentChar);
			currentChar = nextChar();
		}
		
		return new Token(NUMBER, Double.parseDouble(res.toString()));
	}

	/**
	 * 当前字符
	 * **/
	private char currentChar() {

		// 没有输入?
		if (line == null) {
			return (char) 0;
		}

		// 行末?
		else if (currentPos >= line.length()) {
			return (char) 0;
		}

		// 返回当前字符
		else {
			return line.charAt(currentPos);
		}
	}
	
	/**
	 * 下一字符
	 * **/
	private char nextChar() {
		++currentPos;
		return currentChar();
	}
	
	public static void main(String[] args) throws Exception {
		Scanner a = new Scanner(new StringReader("12.0322+22+2=776+66fg"));
		for(int i = 0; i < 10; i++) {
			Token b = a.extractToken();
			if(b.getType() == NUMBER) {
				System.out.println(b.getNumber());
			}
			System.out.println(b.getType().toString());
		}
	}
}
