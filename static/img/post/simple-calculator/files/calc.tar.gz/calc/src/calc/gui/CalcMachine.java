package calc.gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.StringReader;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

import calc.back.Calculator;

/**
 * 简易的计算UI
 * @author Crimx
 *
 */
public class CalcMachine extends JFrame{

	private static final long serialVersionUID = 1L;
	
	private JTextField text;
	private JTextField result;
	private JButton calcBu;

	public CalcMachine() {
		try {  
            UIManager.setLookAndFeel(  
            UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {  
            e.printStackTrace();  
        }
		setTitle("简易计算器");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setUI();
		setListener();
		pack();
		setVisible(true);
		text.setText(""); // 走了偏门去控制JtextField的宽度，如果你有办法记得告诉我
	}

	private void setUI() {
		setLayout(new GridLayout(2,1));
		
		JPanel up = new JPanel();
		text = new JTextField("                      ");
		up.add(text);
		up.add(new JLabel(" = "));
		result = new JTextField("        ");
		result.setEditable(false);
		up.add(result);
		
		JPanel down = new JPanel();
		calcBu = new JButton("Calculate");
		down.add(calcBu);
		
		add(up);
		add(down);
	}

	private void setListener() {

		calcBu.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Calculator a;
						try {
							a = new Calculator(new StringReader(text.getText()));
							result.setText(Double.toString(a.calculate()));
						} catch (Exception e1) {
							JOptionPane.showOptionDialog(null,
									Pattern.compile("^.*Exception:").matcher(e1.toString()).replaceAll(""),
									"错误",
									JOptionPane.DEFAULT_OPTION,
									JOptionPane.INFORMATION_MESSAGE,
									null, null, null);
						}
					}
				});
	}
	
	public static void main(String args[]) {
		new CalcMachine();
	}
}
