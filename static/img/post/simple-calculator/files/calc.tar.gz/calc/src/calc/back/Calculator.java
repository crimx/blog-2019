package calc.back;

import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;

import calc.front.*;

/**
 * 简易计算器
 * 
 * @author Crimx
 *
 */
public class Calculator {
	
	private Parser parser;
	
	public Calculator(Reader reader) throws Exception {
		
		this.parser = new Parser(reader);
	}
	
	public double calculate() throws Exception {
		
		Token token = parser.parse();
		
		return calculate(token);
	}
	
	private double calculate(Token token) throws Exception {
		
		if(token != null) {
			ArrayList<Token> children = token.getChildren();
			if(children == null) {
				return token.getNumber();
			}
			else {
				switch(token.getType()) {
				case PLUS : {
					return calculate(children.get(0)) + calculate(children.get(1));
				}
				case MINUS : {
					return calculate(children.get(0)) - calculate(children.get(1));
				}
				case STAR : {
					return calculate(children.get(0)) * calculate(children.get(1));
				}
				case SLASH : {
					return calculate(children.get(0)) / calculate(children.get(1));
				}
				case NEGATE : {
					return -1 * calculate(children.get(0));
				}
				default : throw new Exception("计算出错！" + token.getType().toString());
				}
			}
		}
		return 0;
	}
	
	public static void main(String args[]) throws Exception {
		
		Calculator c = new Calculator(new StringReader("-1+(8+2-1)/3"));
		
		System.out.println(c.calculate());
	}
}
