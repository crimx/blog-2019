package calc.front;

import java.io.Reader;
import java.io.StringReader;

import static calc.front.TokenType.*;

/**
 * 
 * 语法分析，生成中间代码
 * 
 * @author Crimx
 *
 */
public class Parser {
	
	private Scanner scanner;
	private Token root; //树根结点
	
	private Token token;
	private TokenType tokenType;
	
	public Parser(Reader reader) throws Exception {
		scanner = new Scanner(reader);
		nextToken();
	}
	
	public Parser(Scanner scanner) throws Exception {
		this.scanner = scanner;
		nextToken();
	}
	
	public Token parse() throws Exception {
		root = parseExpression();
		return root;
	}
	
	private Token parseExpression() throws Exception {
		
		Token signToken = null; //加减号在这里代表正负号
		
		while(tokenType == PLUS || tokenType == MINUS) {
			signToken = token;
			nextToken(); // 消耗掉符号
		}
		
		Token root = parseTerm();
		
		//正号可以忽略，负号把项做孩子，负号成为新根节点
		if(signToken != null) {
			if(signToken.getType() == MINUS) {
				signToken.setType(NEGATE);
				signToken.addChild(root);
				root = signToken;
			}
		}
		
		while(tokenType == PLUS || tokenType == MINUS) {
			token.addChild(root);
			root = token;
			nextToken(); // 消耗操作符
			
			root.addChild(parseTerm());
		}
		
		return root;
		
	}
	
	private Token parseTerm() throws Exception {
		
		Token root = parseFactor();
		
		while(tokenType == STAR || tokenType == SLASH) {
			token.addChild(root);
			root = token;
			nextToken(); //消耗操作符
			
			root.addChild(parseFactor());
		}
		
		return root;
	}
	
	private Token parseFactor() throws Exception {
		
		Token root = null;
		
		switch(tokenType) {
		case NUMBER: {
			root = token; 
			nextToken(); //消耗数字
			break;
		}
		case LEFT_PAREN: {
			nextToken(); // 消耗左括号
			
			root = parseExpression();
			
			if(tokenType == RIGHT_PAREN) {
				nextToken(); // 消耗右括号
			} 
			else {
				throw new Exception("括号不匹配！");
			}
			break;
		}
		case EOF: {
			return null;
		}
		default: throw new Exception("表达式不正确！");
		}
		
		return root;
	}
	
	// 方便调用
	private void nextToken() throws Exception {
		token = scanner.extractToken();
		tokenType = token.getType();
	}

	//getter和setter
	public Scanner getScanner() {
		return scanner;
	}

	public void setScanner(Scanner scanner) {
		this.scanner = scanner;
	}

	public Token getRoot() {
		return root;
	}
	
	public String toString() {
		return root.toString();
	}
	
	public static void main(String[] args) throws Exception {
		Parser a = new Parser(new StringReader("1+2*3+(4-5)"));
		a.parse();
		System.out.println(a.toString());
	}
}
