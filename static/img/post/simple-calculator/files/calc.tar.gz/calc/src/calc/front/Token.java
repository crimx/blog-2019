package calc.front;

import java.util.ArrayList;

/**
 * <h1>符号</h1>
 * 
 * <p>
 * 符号为语法单元，每个符号都是符合词法的
 * </p>
 * 
 * @author Crimx
 * 
 */
public class Token {

	private TokenType type; // 该token的类型
	private double number; // 数字
	private String op; // 操作符

	private ArrayList<Token> children = null; // 孩子

	public Token(TokenType type) {
		this.type = type;
	}

	public Token(TokenType type, double number) {
		this.type = type;
		this.number = number;
	}

	public Token(TokenType type, char op) {
		this.type = type;
		this.op = String.valueOf(op);
	}

	public void addChild(Token token) {
		if (token != null) {
			if (children == null) {
				children = new ArrayList<Token>();
			}
			children.add(token);
		}
	}

	/**
	 * 返回整棵树
	 */
	public String toString() {
		return toString(0);
	}
	public String toString(int level) {
		
		StringBuffer text = new StringBuffer();
		
		if (children == null) {
			text.append('\n');
			for(int j = 0; j < level; j++) {
				text.append("|  ");
			}
			text.append(getValue());
		} else {
			for(int i = 0; i < children.size(); i++) {
				text.append('\n');
				for(int j = 0; j < level; j++) {
					text.append("|  ");
				}
				text.append(getValue());
				text.append(children.get(i).toString(level+1));
			}
		}
		
		return text.toString();
	}


	// 下面为getter和setter
	public TokenType getType() {
		return type;
	}

	public void setType(TokenType type) {
		this.type = type;
	}

	public double getNumber() {
		return number;
	}

	public void setNumber(double number) {
		this.number = number;
	}

	public ArrayList<Token> getChildren() {
		return children;
	}

	public String getValue() {
		if (type == TokenType.NUMBER) {
			return Double.toString(number);
		}
		return op;
	}
}
